#!/bin/bash
# 悉昙 IAST 原生键盘布局 · macOS 安装脚本
# 只动你自己家目录下的两个位置，不碰系统目录，随时可用「卸载.command」还原。
set -u

HERE="$(cd "$(dirname "$0")" && pwd)"
BUNDLE="SiddhamIAST.bundle"
FONT="NotoSansSiddham-Regular.ttf"
KL_DIR="$HOME/Library/Keyboard Layouts"
FONT_DIR="$HOME/Library/Fonts"

echo "==============================================="
echo "  悉昙 IAST · macOS 原生键盘布局 安装"
echo "==============================================="
echo

if [ ! -d "$HERE/$BUNDLE" ]; then
  echo "✗ 找不到 $BUNDLE —— 请把整个文件夹解压后再运行，不要单独移动文件。"
  echo
  read -n 1 -s -r -p "按任意键关闭…"; exit 1
fi

# 去掉下载隔离标记，避免后续系统反复弹「无法验证」
xattr -dr com.apple.quarantine "$HERE/$BUNDLE" 2>/dev/null || true

echo "→ 安装键盘布局到：$KL_DIR"
mkdir -p "$KL_DIR"
rm -rf "$KL_DIR/$BUNDLE"
cp -R "$HERE/$BUNDLE" "$KL_DIR/$BUNDLE"
xattr -dr com.apple.quarantine "$KL_DIR/$BUNDLE" 2>/dev/null || true
echo "  ✓ 完成"

if [ -f "$HERE/$FONT" ]; then
  echo "→ 安装字体到：$FONT_DIR"
  mkdir -p "$FONT_DIR"
  cp -f "$HERE/$FONT" "$FONT_DIR/$FONT"
  xattr -dr com.apple.quarantine "$FONT_DIR/$FONT" 2>/dev/null || true
  echo "  ✓ 完成（Noto Sans Siddham，SIL OFL 授权，可自由分发）"
fi

echo
echo "==============================================="
echo "  装好了。还剩两步（必须做，否则找不到键盘）："
echo "==============================================="
echo
echo "  1) 注销一次再登录（或用「系统设置 → 用户与群组 → 重新登录」）"
echo "     键盘布局只在登录时才被系统扫描，不注销就不会出现。"
echo
echo "  2) 系统设置 → 键盘 → 文字输入 → 输入法 → 编辑… → 点 ＋"
echo "     在「印地语」分类下找「悉昙 IAST」，添加它。"
echo
echo "  切换：菜单栏输入法图标，或按 Control + 空格"
echo
echo "  不想要了：双击同目录下的「卸载.command」即可完全移除。"
echo
read -n 1 -s -r -p "按任意键关闭…"
