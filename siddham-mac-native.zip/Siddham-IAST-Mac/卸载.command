#!/bin/bash
# 悉昙 IAST 原生键盘布局 · 卸载脚本
set -u

BUNDLE="SiddhamIAST.bundle"
FONT="NotoSansSiddham-Regular.ttf"
KL_DIR="$HOME/Library/Keyboard Layouts"
FONT_DIR="$HOME/Library/Fonts"

echo "==============================================="
echo "  悉昙 IAST · 卸载"
echo "==============================================="
echo
read -n 1 -s -r -p "确认卸载悉昙 IAST 键盘布局和字体？(y/N) " ans
echo
case "$ans" in
  y|Y) ;;
  *) echo "已取消，什么都没改。"; read -n 1 -s -r -p "按任意键关闭…"; exit 0 ;;
esac

if [ -d "$KL_DIR/$BUNDLE" ]; then
  rm -rf "$KL_DIR/$BUNDLE"
  echo "✓ 已移除键盘布局"
else
  echo "· 键盘布局本来就不在，跳过"
fi

if [ -f "$FONT_DIR/$FONT" ]; then
  rm -f "$FONT_DIR/$FONT"
  echo "✓ 已移除字体"
else
  echo "· 字体本来就不在，跳过"
fi

echo
echo "注销重登录一次，输入法列表里就干净了。"
echo
read -n 1 -s -r -p "按任意键关闭…"
